
IMPORTANT NOTICE:
-----------------

All icons by Agus Purwanto from the Noun Project. Thanks a lot!
https://thenounproject.com/Brexebrex/collection/chart-icons/